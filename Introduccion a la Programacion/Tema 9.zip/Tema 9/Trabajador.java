public class Trabajador extends Persona {
    private double sueldo;

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo=sueldo;
    }
    
}
